package com.ems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmsAngularBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmsAngularBackendApplication.class, args);
	}

}
